"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function RDPClient() {
  const [isConnected, setIsConnected] = useState(false);
  const [hostAddress, setHostAddress] = useState("");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (isConnected && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (ctx) {
        // Simulating a remote desktop screen
        ctx.fillStyle = "lightblue";
        ctx.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        ctx.font = "20px Arial";
        ctx.fillStyle = "black";
        ctx.textAlign = "center";
        ctx.fillText(
          "Remote Desktop Screen",
          canvasRef.current.width / 2,
          canvasRef.current.height / 2
        );
      }
    }
  }, [isConnected]);

  const handleConnect = async () => {
    try {
      const response = await fetch("/api/connect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hostAddress }),
      });

      if (response.ok) {
        setIsConnected(true);
        console.log(`Connected to ${hostAddress}`);
      } else {
        console.error("Failed to connect");
      }
    } catch (error) {
      console.error("Error connecting:", error);
    }
  };

  const handleDisconnect = async () => {
    try {
      const response = await fetch("/api/disconnect", {
        method: "POST",
      });

      if (response.ok) {
        setIsConnected(false);
        console.log("Disconnected");
      } else {
        console.error("Failed to disconnect");
      }
    } catch (error) {
      console.error("Error disconnecting:", error);
    }
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
      <div className="mb-4">
        <Label htmlFor="host-address">Host Address</Label>
        <Input
          id="host-address"
          type="text"
          placeholder="Enter host address"
          value={hostAddress}
          onChange={(e) => setHostAddress(e.target.value)}
          className="w-full mt-1"
        />
      </div>
      <Button
        onClick={isConnected ? handleDisconnect : handleConnect}
        className={`w-full ${
          isConnected
            ? "bg-red-500 hover:bg-red-600"
            : "bg-green-500 hover:bg-green-600"
        }`}
      >
        {isConnected ? "Disconnect" : "Connect"}
      </Button>
      <div className="mt-4 border-2 border-gray-300 rounded-lg p-4 h-64 flex items-center justify-center">
        {isConnected ? (
          <canvas
            ref={canvasRef}
            width={400}
            height={300}
            className="w-full h-full object-contain"
          />
        ) : (
          <p className="text-gray-500">Not connected</p>
        )}
      </div>
    </div>
  );
}
