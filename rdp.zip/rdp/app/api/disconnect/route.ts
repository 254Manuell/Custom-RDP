import { NextResponse } from 'next/server'

export async function POST() {
  // In a real implementation, you would close the RDP connection here
  console.log('Disconnecting')
  
  // Simulating a successful disconnection
  return NextResponse.json({ success: true })
}

